/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameState : MonoBehaviour
{

    public GameObject SA_Unit;


    // Start is called before the first frame update
    public void GameClear()
    {
        
        SA_Unit.GetComponent<SA_Unit>().SetState(global::SA_Unit.UnitState.death);
    }
}*/
