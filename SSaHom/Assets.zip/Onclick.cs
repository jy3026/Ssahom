using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Onclick : MonoBehaviour
{

    SA_Unit _unitST;

    public GameObject Unit000;
    public GameObject Unit001;
    public GameObject Unit002;
    public GameObject Unit003;
    public GameObject Unit004;
    public GameObject Unit005;
    public GameObject Unit006;
    public GameObject Unit007;
    public GameObject Unit008;
    public GameObject Unit009;
    public GameObject Unit010;
    public GameObject Unit011;
    public GameObject Unit012;
    public GameObject Unit013;
    public GameObject Unit014;

    public GameObject button00;
    public GameObject button01;
    public GameObject button02;
    public GameObject button03;
    public GameObject button04;
    public GameObject button05;
    public GameObject button06;
    public GameObject button07;
    public GameObject button08;
    public GameObject button09;
    public GameObject button10;
    public GameObject button11;
    public GameObject button12;
    public GameObject button13;
    public GameObject button14;

    public GameObject button000;
    public GameObject button001;
    public GameObject button002;
    public GameObject button003;
    public GameObject button004;
    public GameObject button005;
    public GameObject button006;
    public GameObject button007;
    public GameObject button008;
    public GameObject button009;
    public GameObject button010;
    public GameObject button011;
    public GameObject button012;
    public GameObject button013;
    public GameObject button014;

    public GameObject introduce1;
    public GameObject introduce2;
    public GameObject introduce3;

    public GameObject pickclose;
    public GameObject enemy;
    public GameObject Clear;
    public GameObject Win;
    public GameObject Over;
    public GameObject defeat;
    NoticeUI _notice;


    private Text Score;
    private int score = 0;
    private int score1 = 0;

    public GameObject Monster1;
    public GameObject Monster2;
    public GameObject Monster3;
    public GameObject Monster4;

    public GameObject HealthBar0;
    public GameObject HealthBar1;
    public GameObject HealthBar2;
    public GameObject HealthBar3;
    public GameObject HealthBar4;
    public GameObject HealthBar5;
    public GameObject HealthBar6;
    public GameObject HealthBar7;
    public GameObject HealthBar8;
    public GameObject HealthBar9;
    public GameObject HealthBar10;
    public GameObject HealthBar11;
    public GameObject HealthBar12;
    public GameObject HealthBar13;
    public GameObject HealthBar14;
    public GameObject ManaBar0;
    public GameObject ManaBar1;
    public GameObject ManaBar2;
    public GameObject ManaBar3;
    public GameObject ManaBar4;
    public GameObject ManaBar5;
    public GameObject ManaBar6;
    public GameObject ManaBar7;
    public GameObject ManaBar8;
    public GameObject ManaBar9;
    public GameObject ManaBar10;
    public GameObject ManaBar11;
    public GameObject ManaBar12;
    public GameObject ManaBar13;
    public GameObject ManaBar14;

    public GameObject MonsterHealthBar0;
    public GameObject MonsterHealthBar1;
    public GameObject MonsterHealthBar2;
    public GameObject MonsterHealthBar3;
    public GameObject MonsterManaBar0;
    public GameObject MonsterManaBar1;
    public GameObject MonsterManaBar2;
    public GameObject MonsterManaBar3;

    private int Timer = 0;
    public GameObject Num_A;
    public GameObject Num_B;
    public GameObject Num_C;
    public GameObject Num_GO;
    void Awake()
    {
        _notice = FindObjectOfType<NoticeUI>();
    }

    void Start()
    {
        Timer = 0;
        //Num_A.SetActive(false);
        //Num_B.SetActive(false);
        //Num_C.SetActive(false);
        //Num_GO.SetActive(false);
        Score = GameObject.Find("myscore").GetComponent<Text>();
    }
    // Start is called before the first frame update
    public void Unit000Set()
    {
        Unit000.SetActive(true);
        button00.SetActive(false);
        button01.SetActive(false);
        button02.SetActive(false);
        button03.SetActive(false);
        button04.SetActive(false);
        button05.SetActive(true);
        button06.SetActive(true);
        button07.SetActive(true);
        button08.SetActive(true);
        button09.SetActive(true);
        //button000.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(true);
    }
    public void Unit001Set()
    {
        Unit001.SetActive(true);
        button00.SetActive(false);
        button01.SetActive(false);
        button02.SetActive(false);
        button03.SetActive(false);
        button04.SetActive(false);
        button05.SetActive(true);
        button06.SetActive(true);
        button07.SetActive(true);
        button08.SetActive(true);
        button09.SetActive(true);
        //button001.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(true);
    }
    public void Unit002Set()
    {
        Unit002.SetActive(true);
        button00.SetActive(false);
        button01.SetActive(false);
        button02.SetActive(false);
        button03.SetActive(false);
        button04.SetActive(false);
        button05.SetActive(true);
        button06.SetActive(true);
        button07.SetActive(true);
        button08.SetActive(true);
        button09.SetActive(true);
        //button002.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(true);
    }
    public void Unit003Set()
    {
        Unit003.SetActive(true);
        button00.SetActive(false);
        button01.SetActive(false);
        button02.SetActive(false);
        button03.SetActive(false);
        button04.SetActive(false);
        button05.SetActive(true);
        button06.SetActive(true);
        button07.SetActive(true);
        button08.SetActive(true);
        button09.SetActive(true);
        //button003.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(true);
    }
    public void Unit004Set()
    {
        Unit004.SetActive(true);
        button00.SetActive(false);
        button01.SetActive(false);
        button02.SetActive(false);
        button03.SetActive(false);
        button04.SetActive(false);
        button05.SetActive(true);
        button06.SetActive(true);
        button07.SetActive(true);
        button08.SetActive(true);
        button09.SetActive(true);
        //button004.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(true);
    }

    public void Unit005Set()
    {
        Unit005.SetActive(true);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(true);
        button11.SetActive(true);
        button12.SetActive(true);
        button13.SetActive(true);
        button14.SetActive(true);
        //button005.SetActive(true);
        introduce1.SetActive(false);
        introduce2.SetActive(false);
        introduce3.SetActive(true);
    }
    public void Unit006Set()
    {
        Unit006.SetActive(true);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(true);
        button11.SetActive(true);
        button12.SetActive(true);
        button13.SetActive(true);
        button14.SetActive(true);
        introduce2.SetActive(false);
        introduce3.SetActive(true);
    }
    public void Unit007Set()
    {
        Unit007.SetActive(true);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(true);
        button11.SetActive(true);
        button12.SetActive(true);
        button13.SetActive(true);
        button14.SetActive(true);
        introduce2.SetActive(false);
        introduce3.SetActive(true);
    }
    public void Unit008Set()
    {
        Unit008.SetActive(true);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(true);
        button11.SetActive(true);
        button12.SetActive(true);
        button13.SetActive(true);
        button14.SetActive(true);
        introduce2.SetActive(false);
        introduce3.SetActive(true);
    }
    public void Unit009Set()
    {
        Unit009.SetActive(true);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(true);
        button11.SetActive(true);
        button12.SetActive(true);
        button13.SetActive(true);
        button14.SetActive(true);
        introduce2.SetActive(false);
        introduce3.SetActive(true);
    }

    public void Unit010Set()
    {
        Unit010.SetActive(true);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button000.SetActive(true);
        button001.SetActive(true);
        button002.SetActive(true);
        button003.SetActive(true);
        button004.SetActive(true);
        button005.SetActive(true);
        button006.SetActive(true);
        button007.SetActive(true);
        button008.SetActive(true);
        button009.SetActive(true);
        button010.SetActive(true);
        button011.SetActive(true);
        button012.SetActive(true);
        button013.SetActive(true);
        button014.SetActive(true);
        introduce3.SetActive(false);
    }

    public void Unit011Set()
    {
        Unit011.SetActive(true);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button000.SetActive(true);
        button001.SetActive(true);
        button002.SetActive(true);
        button003.SetActive(true);
        button004.SetActive(true);
        button005.SetActive(true);
        button006.SetActive(true);
        button007.SetActive(true);
        button008.SetActive(true);
        button009.SetActive(true);
        button010.SetActive(true);
        button011.SetActive(true);
        button012.SetActive(true);
        button013.SetActive(true);
        button014.SetActive(true);
        introduce3.SetActive(false);

    }

    public void Unit012Set()
    {
        Unit012.SetActive(true);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button000.SetActive(true);
        button001.SetActive(true);
        button002.SetActive(true);
        button003.SetActive(true);
        button004.SetActive(true);
        button005.SetActive(true);
        button006.SetActive(true);
        button007.SetActive(true);
        button008.SetActive(true);
        button009.SetActive(true);
        button010.SetActive(true);
        button011.SetActive(true);
        button012.SetActive(true);
        button013.SetActive(true);
        button014.SetActive(true);
        introduce3.SetActive(false);
    }

    public void Unit013Set()
    {
        Unit013.SetActive(true);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button000.SetActive(true);
        button001.SetActive(true);
        button002.SetActive(true);
        button003.SetActive(true);
        button004.SetActive(true);
        button005.SetActive(true);
        button006.SetActive(true);
        button007.SetActive(true);
        button008.SetActive(true);
        button009.SetActive(true);
        button010.SetActive(true);
        button011.SetActive(true);
        button012.SetActive(true);
        button013.SetActive(true);
        button014.SetActive(true);
        introduce3.SetActive(false);
    }

    public void Unit0014Set()
    {
        Unit014.SetActive(true);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button000.SetActive(true);
        button001.SetActive(true);
        button002.SetActive(true);
        button003.SetActive(true);
        button004.SetActive(true);
        button005.SetActive(true);
        button006.SetActive(true);
        button007.SetActive(true);
        button008.SetActive(true);
        button009.SetActive(true);
        button010.SetActive(true);
        button011.SetActive(true);
        button012.SetActive(true);
        button013.SetActive(true);
        button014.SetActive(true);
        introduce3.SetActive(false);
    }

    public void Unit000Set1()
    {
        if(Unit000.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if(Unit000.activeSelf == false)
        {
            Unit000.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit001Set1()
    {
        if (Unit001.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit001.activeSelf == false)
        {
            Unit001.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit002Set1()
    {
        if (Unit002.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit002.activeSelf == false)
        {
            Unit002.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit003Set1()
    {
        if (Unit003.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit003.activeSelf == false)
        {
            Unit003.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit004Set1()
    {
        if (Unit004.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit004.activeSelf == false)
        {
            Unit004.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit005Set1()
    {
        if (Unit005.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit005.activeSelf == false)
        {
            Unit005.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit006Set1()
    {
        if (Unit006.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit006.activeSelf == false)
        {
            Unit006.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit007Set1()
    {
        if (Unit007.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit007.activeSelf == false)
        {
            Unit007.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit008Set1()
    {
        if (Unit008.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit008.activeSelf == false)
        {
            Unit008.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit009Set1()
    {
        if (Unit009.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit009.activeSelf == false)
        {
            Unit009.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }
    }

    public void Unit010Set1()
    {
        if (Unit010.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit010.activeSelf == false)
        {
            Unit010.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }

    }
    public void Unit011Set1()
    {
        if (Unit011.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit011.activeSelf == false)
        {
            Unit011.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }

    }

    public void Unit012Set1()
    {
        if (Unit012.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit012.activeSelf == false)
        {
            Unit012.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }

    }

    public void Unit014Set1()
    {
        if (Unit014.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit014.activeSelf == false)
        {
            Unit014.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }

    }

    public void Unit013Set1()
    {
        if (Unit013.activeSelf == true)
        {
            _notice.SUB("�̹� ���õ� �뺴 �Դϴ�.");
        }
        else if (Unit013.activeSelf == false)
        {
            Unit013.SetActive(true);
            button000.SetActive(false);
            button001.SetActive(false);
            button002.SetActive(false);
            button003.SetActive(false);
            button004.SetActive(false);
            button005.SetActive(false);
            button006.SetActive(false);
            button007.SetActive(false);
            button008.SetActive(false);
            button009.SetActive(false);
            button010.SetActive(false);
            button011.SetActive(false);
            button012.SetActive(false);
            button013.SetActive(false);
            button014.SetActive(false);
        }

    }

    public void Close()
    {
        
        


       if(Unit000.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit000.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit001.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit001.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit002.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit002.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit003.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit003.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit004.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit004.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit005.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit005.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit006.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit006.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit007.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit007.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit008.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit008.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit009.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit009.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit010.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit010.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit011.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit011.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit012.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit012.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit013.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit013.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }
        if (Unit014.GetComponent<SA_Unit>().gameObject.activeSelf == false)
        {
            Unit014.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.death;
        }


        StartCoroutine(this.LoadingEnd());

    }

    public void ReSelect()
    {
        Unit000.SetActive(false);
        Unit001.SetActive(false);
        Unit002.SetActive(false);
        Unit003.SetActive(false);
        Unit004.SetActive(false);
        Unit005.SetActive(false);
        Unit006.SetActive(false);
        Unit007.SetActive(false);
        Unit008.SetActive(false);
        Unit009.SetActive(false);
        Unit010.SetActive(false);
        Unit011.SetActive(false);
        Unit012.SetActive(false);
        Unit013.SetActive(false);
        Unit014.SetActive(false);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button00.SetActive(true);
        button01.SetActive(true);
        button02.SetActive(true);
        button03.SetActive(true);
        button04.SetActive(true);
        button000.SetActive(false);
        button001.SetActive(false);
        button002.SetActive(false);
        button003.SetActive(false);
        button004.SetActive(false);
        button005.SetActive(false);
        button006.SetActive(false);
        button007.SetActive(false);
        button008.SetActive(false);
        button009.SetActive(false);
        button010.SetActive(false);
        button011.SetActive(false);
        button012.SetActive(false);
        button013.SetActive(false);
        button014.SetActive(false);
        
        
        introduce3.SetActive(false);
        introduce2.SetActive(false);
        introduce1.SetActive(true);

    }

    public void NextRound()
    {
        pickclose.SetActive(true);
        Unit000.SetActive(false);
        Unit001.SetActive(false);
        Unit002.SetActive(false);
        Unit003.SetActive(false);
        Unit004.SetActive(false);
        Unit005.SetActive(false);
        Unit006.SetActive(false);
        Unit007.SetActive(false);
        Unit008.SetActive(false);
        Unit009.SetActive(false);
        Unit010.SetActive(false);
        Unit011.SetActive(false);
        Unit012.SetActive(false);
        Unit013.SetActive(false);
        Unit014.SetActive(false);
        enemy.SetActive(false);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button00.SetActive(true);
        button01.SetActive(true);
        button02.SetActive(true);
        button03.SetActive(true);
        button04.SetActive(true);
        button000.SetActive(false);
        button001.SetActive(false);
        button002.SetActive(false);
        button003.SetActive(false);
        button004.SetActive(false);
        button005.SetActive(false);
        button006.SetActive(false);
        button007.SetActive(false);
        button008.SetActive(false);
        button009.SetActive(false);
        button010.SetActive(false);
        button011.SetActive(false);
        button012.SetActive(false);
        button013.SetActive(false);
        button014.SetActive(false);


        introduce3.SetActive(false);
        introduce2.SetActive(false);
        introduce1.SetActive(true);
        Clear.SetActive(false);

        Unit000.GetComponent<SA_Unit>().Health = 300;
        Unit001.GetComponent<SA_Unit>().Health = 300;
        Unit002.GetComponent<SA_Unit>().Health = 300;
        Unit003.GetComponent<SA_Unit>().Health = 300;
        Unit004.GetComponent<SA_Unit>().Health = 300;
        Unit005.GetComponent<SA_Unit>().Health = 300;
        Unit006.GetComponent<SA_Unit>().Health = 300;
        Unit007.GetComponent<SA_Unit>().Health = 300;
        Unit008.GetComponent<SA_Unit>().Health = 300;
        Unit009.GetComponent<SA_Unit>().Health = 300;
        Unit010.GetComponent<SA_Unit>().Health = 300;
        Unit011.GetComponent<SA_Unit>().Health = 300;
        Unit012.GetComponent<SA_Unit>().Health = 300;
        Unit013.GetComponent<SA_Unit>().Health = 300;
        Unit014.GetComponent<SA_Unit>().Health = 300;
        Unit000.GetComponent<SA_Unit>().Mana = 300;
        Unit001.GetComponent<SA_Unit>().Mana = 300;
        Unit002.GetComponent<SA_Unit>().Mana = 300;
        Unit003.GetComponent<SA_Unit>().Mana = 300;
        Unit004.GetComponent<SA_Unit>().Mana = 300;
        Unit005.GetComponent<SA_Unit>().Mana = 300;
        Unit006.GetComponent<SA_Unit>().Mana = 300;
        Unit007.GetComponent<SA_Unit>().Mana = 300;
        Unit008.GetComponent<SA_Unit>().Mana = 300;
        Unit009.GetComponent<SA_Unit>().Mana = 300;
        Unit010.GetComponent<SA_Unit>().Mana = 300;
        Unit011.GetComponent<SA_Unit>().Mana = 300;
        Unit012.GetComponent<SA_Unit>().Mana = 300;
        Unit013.GetComponent<SA_Unit>().Mana = 300;
        Unit014.GetComponent<SA_Unit>().Mana = 300;
        Unit000.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit001.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit002.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit003.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit004.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit005.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit006.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit007.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit008.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit009.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit010.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit011.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit012.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit013.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit014.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        HealthBar0.GetComponent<Image>().fillAmount = 1;
        HealthBar1.GetComponent<Image>().fillAmount = 1;
        HealthBar2.GetComponent<Image>().fillAmount = 1;
        HealthBar3.GetComponent<Image>().fillAmount = 1;
        HealthBar4.GetComponent<Image>().fillAmount = 1;
        HealthBar5.GetComponent<Image>().fillAmount = 1;
        HealthBar6.GetComponent<Image>().fillAmount = 1;
        HealthBar7.GetComponent<Image>().fillAmount = 1;
        HealthBar8.GetComponent<Image>().fillAmount = 1;
        HealthBar9.GetComponent<Image>().fillAmount = 1;
        HealthBar10.GetComponent<Image>().fillAmount = 1;
        HealthBar11.GetComponent<Image>().fillAmount = 1;
        HealthBar12.GetComponent<Image>().fillAmount = 1;
        HealthBar13.GetComponent<Image>().fillAmount = 1;
        HealthBar14.GetComponent<Image>().fillAmount = 1;
        ManaBar0.GetComponent<Image>().fillAmount = 0;
        ManaBar1.GetComponent<Image>().fillAmount = 0;
        ManaBar2.GetComponent<Image>().fillAmount = 0;
        ManaBar3.GetComponent<Image>().fillAmount = 0;
        ManaBar4.GetComponent<Image>().fillAmount = 0;
        ManaBar5.GetComponent<Image>().fillAmount = 0;
        ManaBar6.GetComponent<Image>().fillAmount = 0;
        ManaBar7.GetComponent<Image>().fillAmount = 0;
        ManaBar8.GetComponent<Image>().fillAmount = 0;
        ManaBar9.GetComponent<Image>().fillAmount = 0;
        ManaBar10.GetComponent<Image>().fillAmount = 0;
        ManaBar11.GetComponent<Image>().fillAmount = 0;
        ManaBar12.GetComponent<Image>().fillAmount = 0;
        ManaBar13.GetComponent<Image>().fillAmount = 0;
        ManaBar14.GetComponent<Image>().fillAmount = 0;

        Monster1.GetComponent<SA_Unit>().Health = 500;
        Monster2.GetComponent<SA_Unit>().Health = 500;
        Monster3.GetComponent<SA_Unit>().Health = 500;
        Monster4.GetComponent<SA_Unit>().Health = 500;
        Monster1.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster2.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster3.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster4.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        MonsterHealthBar0.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar1.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar2.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar3.GetComponent<Image>().fillAmount = 1;
        MonsterManaBar0.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar1.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar2.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar3.GetComponent<Image>().fillAmount = 0;



        score += 1;
        Score.text = ""+ score + " : " + score1 +"" ;

        if(score >= 3)
        {
            Win.SetActive(true);
            pickclose.SetActive(false);
        }
    }
    // Update is called once per frame
    public void falseRound()
    {
        pickclose.SetActive(true);
        Unit000.SetActive(false);
        Unit001.SetActive(false);
        Unit002.SetActive(false);
        Unit003.SetActive(false);
        Unit004.SetActive(false);
        Unit005.SetActive(false);
        Unit006.SetActive(false);
        Unit007.SetActive(false);
        Unit008.SetActive(false);
        Unit009.SetActive(false);
        Unit010.SetActive(false);
        Unit011.SetActive(false);
        Unit012.SetActive(false);
        Unit013.SetActive(false);
        Unit014.SetActive(false);
        enemy.SetActive(false);
        button05.SetActive(false);
        button06.SetActive(false);
        button07.SetActive(false);
        button08.SetActive(false);
        button09.SetActive(false);
        button10.SetActive(false);
        button11.SetActive(false);
        button12.SetActive(false);
        button13.SetActive(false);
        button14.SetActive(false);
        button00.SetActive(true);
        button01.SetActive(true);
        button02.SetActive(true);
        button03.SetActive(true);
        button04.SetActive(true);
        button000.SetActive(false);
        button001.SetActive(false);
        button002.SetActive(false);
        button003.SetActive(false);
        button004.SetActive(false);
        button005.SetActive(false);
        button006.SetActive(false);
        button007.SetActive(false);
        button008.SetActive(false);
        button009.SetActive(false);
        button010.SetActive(false);
        button011.SetActive(false);
        button012.SetActive(false);
        button013.SetActive(false);
        button014.SetActive(false);


        introduce3.SetActive(false);
        introduce2.SetActive(false);
        introduce1.SetActive(true);
        Over.SetActive(false);

        Unit000.GetComponent<SA_Unit>().Health = 300;
        Unit001.GetComponent<SA_Unit>().Health = 300;
        Unit002.GetComponent<SA_Unit>().Health = 300;
        Unit003.GetComponent<SA_Unit>().Health = 300;
        Unit004.GetComponent<SA_Unit>().Health = 300;
        Unit005.GetComponent<SA_Unit>().Health = 300;
        Unit006.GetComponent<SA_Unit>().Health = 300;
        Unit007.GetComponent<SA_Unit>().Health = 300;
        Unit008.GetComponent<SA_Unit>().Health = 300;
        Unit009.GetComponent<SA_Unit>().Health = 300;
        Unit010.GetComponent<SA_Unit>().Health = 300;
        Unit011.GetComponent<SA_Unit>().Health = 300;
        Unit012.GetComponent<SA_Unit>().Health = 300;
        Unit013.GetComponent<SA_Unit>().Health = 300;
        Unit014.GetComponent<SA_Unit>().Health = 300;
        Unit000.GetComponent<SA_Unit>().Mana = 300;
        Unit001.GetComponent<SA_Unit>().Mana = 300;
        Unit002.GetComponent<SA_Unit>().Mana = 300;
        Unit003.GetComponent<SA_Unit>().Mana = 300;
        Unit004.GetComponent<SA_Unit>().Mana = 300;
        Unit005.GetComponent<SA_Unit>().Mana = 300;
        Unit006.GetComponent<SA_Unit>().Mana = 300;
        Unit007.GetComponent<SA_Unit>().Mana = 300;
        Unit008.GetComponent<SA_Unit>().Mana = 300;
        Unit009.GetComponent<SA_Unit>().Mana = 300;
        Unit010.GetComponent<SA_Unit>().Mana = 300;
        Unit011.GetComponent<SA_Unit>().Mana = 300;
        Unit012.GetComponent<SA_Unit>().Mana = 300;
        Unit013.GetComponent<SA_Unit>().Mana = 300;
        Unit014.GetComponent<SA_Unit>().Mana = 300;
        Unit000.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit001.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit002.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit003.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit004.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit005.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit006.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit007.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit008.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit009.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit010.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit011.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit012.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit013.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Unit014.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        HealthBar0.GetComponent<Image>().fillAmount = 1;
        HealthBar1.GetComponent<Image>().fillAmount = 1;
        HealthBar2.GetComponent<Image>().fillAmount = 1;
        HealthBar3.GetComponent<Image>().fillAmount = 1;
        HealthBar4.GetComponent<Image>().fillAmount = 1;
        HealthBar5.GetComponent<Image>().fillAmount = 1;
        HealthBar6.GetComponent<Image>().fillAmount = 1;
        HealthBar7.GetComponent<Image>().fillAmount = 1;
        HealthBar8.GetComponent<Image>().fillAmount = 1;
        HealthBar9.GetComponent<Image>().fillAmount = 1;
        HealthBar10.GetComponent<Image>().fillAmount = 1;
        HealthBar11.GetComponent<Image>().fillAmount = 1;
        HealthBar12.GetComponent<Image>().fillAmount = 1;
        HealthBar13.GetComponent<Image>().fillAmount = 1;
        HealthBar14.GetComponent<Image>().fillAmount = 1;
        ManaBar0.GetComponent<Image>().fillAmount = 0;
        ManaBar1.GetComponent<Image>().fillAmount = 0;
        ManaBar2.GetComponent<Image>().fillAmount = 0;
        ManaBar3.GetComponent<Image>().fillAmount = 0;
        ManaBar4.GetComponent<Image>().fillAmount = 0;
        ManaBar5.GetComponent<Image>().fillAmount = 0;
        ManaBar6.GetComponent<Image>().fillAmount = 0;
        ManaBar7.GetComponent<Image>().fillAmount = 0;
        ManaBar8.GetComponent<Image>().fillAmount = 0;
        ManaBar9.GetComponent<Image>().fillAmount = 0;
        ManaBar10.GetComponent<Image>().fillAmount = 0;
        ManaBar11.GetComponent<Image>().fillAmount = 0;
        ManaBar12.GetComponent<Image>().fillAmount = 0;
        ManaBar13.GetComponent<Image>().fillAmount = 0;
        ManaBar14.GetComponent<Image>().fillAmount = 0;

        Monster1.GetComponent<SA_Unit>().Health = 500;
        Monster2.GetComponent<SA_Unit>().Health = 500;
        Monster3.GetComponent<SA_Unit>().Health = 500;
        Monster4.GetComponent<SA_Unit>().Health = 500;
        Monster1.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster2.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster3.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        Monster4.GetComponent<SA_Unit>()._unitState = SA_Unit.UnitState.idle;
        MonsterHealthBar0.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar1.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar2.GetComponent<Image>().fillAmount = 1;
        MonsterHealthBar3.GetComponent<Image>().fillAmount = 1;
        MonsterManaBar0.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar1.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar2.GetComponent<Image>().fillAmount = 0;
        MonsterManaBar3.GetComponent<Image>().fillAmount = 0;

        score1 += 1;
        Score.text = score + "  :  " + score1;

        if (score1 >= 3)
        {
            defeat.SetActive(true);
            pickclose.SetActive(false);
        }
    }


    void Update()
    {
    }

    IEnumerator LoadingEnd()
    {
        Num_A.SetActive(true);
        yield return new WaitForSeconds(1.0f);
        Num_A.SetActive(false);
        Num_B.SetActive(true);
        yield return new WaitForSeconds(1.0f);
        Num_B.SetActive(false);
        Num_C.SetActive(true);
        yield return new WaitForSeconds(1.0f);
        Num_C.SetActive(false);
        Num_GO.SetActive(true);
        yield return new WaitForSeconds(1.0f);
        Num_GO.SetActive(false);
        pickclose.SetActive(false);
        enemy.SetActive(true);
    }
}
