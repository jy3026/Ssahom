/*using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(SA_UnitSet))]
[CanEditMultipleObjects]
public class SA_UnitEditor : Editor
{
    // Start is called before the first frame update
    public override void OnInspectorGUI()
    {
        SA_UnitSet SPB = (SA_UnitSet)target;
        base.OnInspectorGUI();
        EditorGUILayout.HelpBox("You can reset unit data", MessageType.Error);

        if (GUILayout.Button("Reset Unit", GUILayout.Height(50)))
        {
            SPB.UnitTypeProcess();
        }
    }
}*/
